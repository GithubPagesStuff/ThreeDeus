//
//  AppDelegate.swift
//  ThreeDeusOSx
//
//  Created by Aiden Bradley Albert on 11/16/17.
//  Copyright (c) 2017 Aiden Bradley Albert. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!


    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
        system("mkdir ~/Library/ThreeDeus")

        


        
                system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/NTR.command -O ~/Library/ThreeDeus/NTR.sh")
                system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/Essentials.command -O ~/Library/ThreeDeus/Essentials.sh")
        
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }

    @IBAction func kor(sender: AnyObject) {
                        system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/KOR.command -O ~/Library/ThreeDeus/KOR.sh")
          system("sh ~/Library/ThreeDeus/KOR.sh")
  }

    @IBAction func jpn(sender: AnyObject) {
                system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/JPN.command -O ~/Library/ThreeDeus/JPN.sh")
           system("sh ~/Library/ThreeDeus/JPN.sh")
 }
    @IBAction func eur(sender: AnyObject) {
        system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/EUR.command -O ~/Library/ThreeDeus/EUR.sh")
        system("sh ~/Library/ThreeDeus/EUR.sh")

    }
    @IBAction func usa(sender: AnyObject) {
        system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/USA.command -O ~/Library/ThreeDeus/USA.sh")
        system("sh ~/Library/ThreeDeus/USA.sh")

    }
    @IBAction func wiiu(sender: AnyObject) {
    
          system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/WiiU.command -O ~/Library/ThreeDeus/WiiU.sh")
        system("sh ~/Library/ThreeDeus/WiiU.sh")
    }
    @IBAction func wii(sender: AnyObject) {
        system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/Wii.command -O ~/Library/ThreeDeus/Wii.sh")
        system("sh ~/Library/ThreeDeus/Wii.sh")
    }
    @IBAction func NTR(sender: AnyObject) {
         system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/NTR.command -O ~/Library/ThreeDeus/NTR.sh")
        system("sh ~/Library/ThreeDeus/NTR.sh")
    }
    @IBAction func Essentials(sender: AnyObject) {
         system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/Essentials.command -O ~/Library/ThreeDeus/Essentials.sh")
        system("sh ~/Library/ThreeDeus/Essentials.sh")
    }
    @IBAction func ugo(sender: AnyObject) {
        system("/usr/local/bin/wget https://raw.githubusercontent.com/GithubPagesStuff/ThreeDeus/master/UGO.command -O ~/Library/ThreeDeus/UGO.sh")
        system("sh ~/Library/ThreeDeus/UGO.sh")
    }
    @IBAction func d(sender: AnyObject) {
        system("open http://3ds.guide")
    }
    @IBAction func dsiguide(sender: AnyObject) {
        system("open http://dsiguide.me")
    }
    @IBAction func guideu(sender: AnyObject) {
        system("open http://WiiU.guide")
    }
    @IBAction func guidewii(sender: AnyObject) {
        system("open http://wii.guide")

    }
}

